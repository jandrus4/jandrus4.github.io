 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/system/pins.h"
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/adc/adc.h"
#include "mcc_generated_files/uart/uart1.h"
#include <stdio.h>
/*
    Main application
*/

int main(void)
{
    SYSTEM_Initialize();
    ADC_Initialize();
    UART1_Initialize();
    UART1_Enable();                           //Do I need to Initialize and Enable UART?

    adc_result_t analog_in=0;
    
    while(1)
    {
        
        char tst = 0;
        if (btn_GetValue() == 0){
            if (tst == 1){
                tst = 0;
            } else {
                tst = 1;
            }
            //tst = !tst;
            debug_SetHigh();
            __delay_ms(10);
            
        } else {
            debug_SetLow();
        }
        
        if (tst == 0){
            //debug_SetHigh();
            ADC_ChannelSelect(ADC_CHANNEL_ANA0);  //Select ADC channel AN0 (RA0)
            ADC_ConversionStart();                //Converts analog signal from probe to digital
            while (!ADC_IsConversionDone());      //Loop that looks for converted signals
            analog_in = ADC_ConversionResultGet();//Produces a pH value (voltage for breadboard simulation)
            printf("\n%d", analog_in/819);        //Prints rough whole number estimate of voltage
            if (analog_in >= 1638) {              //Corresponds to 2 V
                if (analog_in <= 2048) {          //Corresponds to 2.5 V
                    IO_RB1_SetHigh();             //Green LED powered by RB1 and red is RB3
                    IO_RB3_SetLow();              //If "pH" (voltage) is safe (2 V - 2.5 V) turn on green LED and turn off red
                    tx_SetLow();
                }
                else {
                    IO_RB1_SetLow();              //If pH value isn't safe, turn on red LED and turn off green
                    IO_RB3_SetHigh();
                    tx_SetHigh();
                }
            }
            else {
                    IO_RB1_SetLow();
                    IO_RB3_SetHigh();
            }
            __delay_ms(500);                     //Space out your results 
        } else {
                    //debug_SetLow();
                    IO_RB1_SetLow();
                    IO_RB3_SetLow();
        }
    }
}